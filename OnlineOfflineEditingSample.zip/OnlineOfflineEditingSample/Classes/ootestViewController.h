//
//  ootestViewController.h
//  OnlineOfflineEditingSample
//
//  Created by esri-wzf on 2/25/13.
//
//

#import <UIKit/UIKit.h>

@interface ootestViewController : UIViewController

@property(nonatomic,strong) UIBarButtonItem *testButton;

@end
